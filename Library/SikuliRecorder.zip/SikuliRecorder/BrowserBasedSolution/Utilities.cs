﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Configuration;

namespace BrowserBasedSolution
{
    class Utils
    {
        public static void CaptureScreen(Rectangle Region, String file)
        {
            try
                {
                    using (Bitmap bmp = new Bitmap(Region.Width, Region.Height))
                    {
                        using (Graphics gScreen = Graphics.FromImage(bmp))
                            gScreen.CopyFromScreen(Region.Location, Point.Empty, Region.Size);
                        bmp.Save(file, System.Drawing.Imaging.ImageFormat.Png);
                    }
            }
            catch (Exception)
            {
                Utils.WriteToFile(Program.LogFile, "[error] Failed to capture screenshot!");
                Environment.Exit(0);
            }
        }
             
        public static Point CurrentMousePosition()
        {
            return Cursor.Position;
        }
        public static void WriteToFile(String filename, String Content)
        {
            try
            {
                using (System.IO.StreamWriter file =
                   new System.IO.StreamWriter(filename, true))
                {
                    file.WriteLine(Content);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadKey();
            }
        }

        public static String GetFromConfigFile(String Key)
        {
            return ConfigurationManager.AppSettings[Key] != null ? ConfigurationManager.AppSettings[Key].ToString() : null;
        }
        public static void StoreToConfigFile(String Key, String Value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            if (config.AppSettings.Settings[Key] == null)
                config.AppSettings.Settings.Add(Key, Value);
            else
                config.AppSettings.Settings[Key].Value = Value;
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name);
        }
    }
}
